# 服务器上粒子效果修复指南

## 🔍 问题分析

在服务器上推送后看不到粒子效果的可能原因：

1. **浏览器缓存** - 浏览器缓存了旧版本的HTML文件
2. **文件未正确部署** - 服务器上的文件可能是旧版本
3. **Canvas元素未找到** - JavaScript执行时机问题
4. **Canvas尺寸为0** - Canvas未正确初始化尺寸
5. **JavaScript错误** - 其他错误导致脚本停止执行

## ✅ 已实施的修复

### 1. **增强的初始化逻辑** 
- ✅ 防止重复初始化
- ✅ 多重检查确保Canvas元素存在
- ✅ 自动重试机制（最多10次）
- ✅ 支持不同DOM加载状态

### 2. **改进的错误处理**
- ✅ 详细的错误日志
- ✅ 初始化验证
- ✅ 动画循环错误捕获

### 3. **Canvas尺寸保护**
- ✅ 默认尺寸设置
- ✅ 尺寸有效性检查
- ✅ 自动调整机制

### 4. **CSS强化**
- ✅ 使用 `!important` 确保样式优先级
- ✅ 添加 `display: block` 确保显示
- ✅ 添加 `pointer-events: none` 避免干扰交互

### 5. **服务器缓存控制**
- ✅ 为 `/` 路由添加 no-cache 头
- ⚠️ 静态文件挂载需要额外配置

## 🔧 服务器端修复步骤

### 步骤 1: 确认文件已更新

在服务器上检查文件：

```bash
# 检查文件是否存在
ls -la static/index.html

# 检查文件修改时间
stat static/index.html

# 检查是否包含最新代码
grep -c "particle-canvas" static/index.html
grep -c "isInitialized" static/index.html  # 应该找到这个新变量
```

### 步骤 2: 清除浏览器缓存

**方法1: 硬刷新**
- Windows/Linux: `Ctrl + Shift + R`
- Mac: `Cmd + Shift + R`

**方法2: 清除缓存**
- Chrome: 设置 → 隐私和安全 → 清除浏览数据
- 选择"缓存的图片和文件"
- 清除后重新加载页面

### 步骤 3: 检查浏览器控制台

打开开发者工具（F12），查看Console标签，应该看到：

```
✅ DOM ready state: complete, initializing particle network...
✅ Canvas resized to 1920x1080
✅ Particle network initialized successfully
   Canvas: 1920x1080
   Particles: 60
```

如果看到错误，记录错误信息。

### 步骤 4: 使用调试页面

访问调试页面：
```
http://your-server:8000/static/particle_debug.html
```

这个页面会显示详细的诊断信息。

### 步骤 5: 测试独立粒子效果

如果主页面不工作，先测试简化版本：
```
http://your-server:8000/static/fix_particle_effect.html
```

## 🛠️ 强制修复方法

### 方法 1: 添加版本号参数

在URL后添加版本号强制刷新：
```
http://your-server:8000/?v=2.0
http://your-server:8000/static/index.html?v=2.0
```

### 方法 2: 检查服务器文件

在服务器上运行：

```bash
# 检查文件内容
head -50 static/index.html | grep -i canvas
tail -100 static/index.html | grep -i particle

# 检查文件大小（应该有粒子效果代码，文件会比较大）
ls -lh static/index.html
```

### 方法 3: 重启服务器

```bash
# 停止服务器
kill $(cat server.pid) 2>/dev/null || pkill -f "web_server.py"

# 重新启动
nohup python3 web_server.py --mode user --port 8000 > server.log 2>&1 &
echo $! > server.pid
```

## 📋 诊断清单

在报告问题前，请完成以下检查：

- [ ] 已硬刷新页面（Ctrl+Shift+R）
- [ ] 检查了浏览器控制台（F12 → Console）
- [ ] 访问了调试页面 `/static/particle_debug.html`
- [ ] 检查了Canvas元素：`document.getElementById('particle-canvas')`
- [ ] 检查了Canvas尺寸：`canvas.width` 和 `canvas.height`
- [ ] 确认服务器上的文件是最新版本
- [ ] 尝试了不同的浏览器
- [ ] 检查了服务器日志是否有错误

## 🔍 快速诊断命令

在浏览器控制台中运行：

```javascript
// 1. 检查Canvas元素
const canvas = document.getElementById('particle-canvas');
console.log('Canvas:', canvas);
console.log('初始化的:', canvas?.dataset.initialized);
console.log('尺寸:', canvas?.width, 'x', canvas?.height);

// 2. 检查Canvas样式
if (canvas) {
    const style = window.getComputedStyle(canvas);
    console.log('显示:', style.display);
    console.log('位置:', style.position);
    console.log('z-index:', style.zIndex);
}

// 3. 手动测试绘制
if (canvas) {
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
    ctx.fillRect(100, 100, 100, 100);
    console.log('✅ 如果看到红色方块，说明Canvas工作正常');
}

// 4. 检查是否有JavaScript错误
window.onerror = function(msg, url, line) {
    console.error('JS错误:', msg, 'at', url, ':', line);
    return false;
};
```

## 🚀 如果仍然无法解决

请提供以下信息：

1. **浏览器信息**
   - 浏览器类型和版本
   - 操作系统

2. **控制台输出**
   - 完整的控制台日志
   - 是否有错误信息
   - "Particle network initialized successfully" 是否出现

3. **DOM检查结果**
   - Canvas元素是否存在
   - Canvas尺寸是多少
   - Canvas是否可见

4. **服务器信息**
   - 服务器类型（本地/远程）
   - 文件修改时间
   - 服务器日志

## 📝 更新日志

### v2.0 (最新)
- ✅ 添加重复初始化保护
- ✅ 改进错误处理和日志
- ✅ 增强Canvas尺寸检查
- ✅ 添加重试机制
- ✅ 创建调试工具页面
